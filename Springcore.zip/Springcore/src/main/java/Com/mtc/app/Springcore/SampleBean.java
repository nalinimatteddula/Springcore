package Com.mtc.app.Springcore;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import daomessage.MessageDAO;

@Component
public class SampleBean {
	
//	@Autowired
//	private MessageDAO messageDAO;
//	
//	public String getMessage() {
//		return messageDAO.fetchMessage();
//	}
//	
	public String getMessage() {
	return "Welcome to Spring Framework";	
	}

}
