package daomessage;

public class MessageDAO {

	public String fetchMessage() {
		return "DB : Welcome to Spring framework";
	}

}
